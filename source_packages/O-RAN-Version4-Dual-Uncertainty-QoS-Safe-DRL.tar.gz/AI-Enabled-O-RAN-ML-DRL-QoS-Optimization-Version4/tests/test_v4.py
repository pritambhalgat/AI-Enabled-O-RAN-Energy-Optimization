import numpy as np

from config import Config
from src.data import finite_sample_quantile
from src.radio import generate_channel_pair, make_combiner, rates_with_combiner
from src.uncertainty import (posterior_channel_parameters, posterior_channel_samples,
                             posterior_rate_quantile)
from src.safety import project_power


def test_conformal_quantile_shape():
    x = np.arange(40, dtype=float).reshape(20, 2)
    q = finite_sample_quantile(x, 0.9)
    assert q.shape == (2,) and np.all(q >= x.min(axis=0))


def test_receiver_rates_finite_with_physical_channel_scale():
    c = Config()
    rng = np.random.default_rng(1)
    ht, he, beta = generate_channel_pair(c, rng, return_beta=True)
    assert beta.shape == (c.n_users,)
    assert np.all(beta > 0) and np.all(beta < 1)
    p = np.ones(c.n_users) * c.p_max_w / c.n_users
    for receiver in c.receiver_names:
        W = make_combiner(he, p, c, receiver)
        _, rates = rates_with_combiner(ht, W, p, c)
        assert W.shape == (c.n_users, c.n_antennas)
        assert np.all(np.isfinite(rates)) and np.all(rates >= 0)


def test_conditional_posterior_is_positive_semidefinite_and_contracts_prior():
    c = Config()
    rng = np.random.default_rng(2)
    _, he, beta = generate_channel_pair(c, rng, return_beta=True)
    means, covariances = posterior_channel_parameters(he, beta, c)
    assert means.shape == he.shape
    assert covariances.shape == (c.n_users, c.n_antennas, c.n_antennas)
    for covariance in covariances:
        assert np.allclose(covariance, covariance.conj().T, atol=1e-18)
        assert np.linalg.eigvalsh(covariance).min() >= -1e-18
    samples = posterior_channel_samples(he, beta, c, rng, n_samples=8)
    assert samples.shape == (8, c.n_antennas, c.n_users)


def test_posterior_lower_rate_shape():
    c = Config()
    rng = np.random.default_rng(3)
    _, he, beta = generate_channel_pair(c, rng, return_beta=True)
    p = np.ones(c.n_users) * c.p_max_w / c.n_users
    hs = posterior_channel_samples(he, beta, c, rng, n_samples=8)
    q = posterior_rate_quantile(he, p, hs, c, "MRC")
    assert q.shape == (c.n_users,) and np.all(np.isfinite(q))


def test_shield_respects_power_budget_even_when_qos_fails():
    c = Config(posterior_samples=8, projection_maxiter=15)
    rng = np.random.default_rng(4)
    _, he, beta = generate_channel_pair(c, rng, return_beta=True)
    p0 = np.ones(c.n_users) * c.p_max_w / c.n_users
    demand = np.ones(c.n_users) * 0.2
    margins = {rx: np.zeros(c.n_users) for rx in c.receiver_names}
    scenarios = posterior_channel_samples(he, beta, c, rng, n_samples=8)
    power, ok = project_power(he, p0, demand, c, "MRC", margins, rng,
                              calibrated=False, posterior_scenarios=scenarios)
    assert np.all(power >= 0) and power.sum() <= c.p_max_w + 1e-5
    assert isinstance(ok, bool)


def test_block_max_calibration_uses_one_score_per_channel_unit():
    # A single channel's candidate action scores become one component-wise max row.
    action_scores = np.array([
        [0.1, 0.2],
        [0.5, 0.1],
        [0.2, 0.8],
        [0.3, 0.4],
    ])
    block_score = np.max(action_scores, axis=0)
    assert np.allclose(block_score, [0.5, 0.8])
