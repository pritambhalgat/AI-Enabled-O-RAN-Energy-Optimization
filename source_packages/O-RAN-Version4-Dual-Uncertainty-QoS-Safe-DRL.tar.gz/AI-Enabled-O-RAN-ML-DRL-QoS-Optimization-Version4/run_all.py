"""Train, calibrate and evaluate the complete Version 4 pipeline."""
import argparse
import subprocess
import sys


def run(command):
    print("+", " ".join(command), flush=True)
    subprocess.run(command, check=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--seeds", type=int, default=10, help="Independent evaluation seeds")
parser.add_argument("--blocks", type=int, default=200, help="Blocks per evaluation seed")
parser.add_argument("--traffic-epochs", type=int, default=100)
parser.add_argument("--calibration-samples", type=int, default=500)
parser.add_argument("--ppo-episodes", type=int, default=250)
parser.add_argument("--ppo-steps", type=int, default=40)
parser.add_argument("--training-seed", type=int, default=55)
parser.add_argument("--calibration-seed", type=int, default=90210)
parser.add_argument("--evaluation-seed-start", type=int, default=7000)
args = parser.parse_args()

run([sys.executable, "-m", "src.train_demand", "--epochs", str(args.traffic_epochs)])
for receiver in ("MRC", "ZF", "MMSE"):
    run([
        sys.executable, "-m", "src.train_ppo", "--receiver", receiver,
        "--episodes", str(args.ppo_episodes), "--steps", str(args.ppo_steps),
        "--seed", str(args.training_seed),
    ])
run([
    sys.executable, "-m", "src.calibrate",
    "--samples", str(args.calibration_samples), "--seed", str(args.calibration_seed),
])
run([
    sys.executable, "-m", "src.evaluate",
    "--seeds", str(args.seeds), "--blocks", str(args.blocks),
    "--seed-start", str(args.evaluation_seed_start),
])
