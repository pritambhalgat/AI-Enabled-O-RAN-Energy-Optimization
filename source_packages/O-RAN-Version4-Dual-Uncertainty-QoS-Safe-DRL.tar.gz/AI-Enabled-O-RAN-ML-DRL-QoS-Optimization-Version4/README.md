# O-RAN Version 4 — Dual-Uncertainty QoS Safety-Shield Research Prototype

This directory contains the complete, reproducible source package for Version 4 of the AI-enabled O-RAN energy-optimization project. It is a simulation research prototype, not a live O-RAN implementation.

## Research question

Can a PPO power-allocation policy be post-processed by an uncertainty-aware action filter that reduces user-level QoS shortfall under uncertain traffic demand and imperfect channel-state information (CSI), while respecting a total transmit-power budget?

## What is implemented

- A synthetic temporally correlated traffic generator and PyTorch demand predictor, with a persistence baseline and one-sided split-conformal demand residuals.
- A 64-antenna, 8-user uplink channel model with spatially correlated Rayleigh fading, log-normal shadowing, close-in path loss at 3.5 GHz, thermal noise plus a 7 dB receiver noise-figure assumption, and imperfect CSI.
- Receiver-specific MRC, ZF and MMSE combining and post-combining SINR/rate calculations.
- Separate PPO controllers for MRC, ZF and MMSE.
- A simulator-consistent conditional Gaussian posterior for the channel given the estimate, derived from the channel prior and CSI-error covariance.
- Receiver-specific lower-tail rate estimates and an SLSQP nearest-action projection that attempts to satisfy conservative QoS constraints and the total power budget.
- Multi-seed evaluation, per-user coverage diagnostics, QoS shortfall, outage, throughput, energy-efficiency, fairness, power and solver-success summaries.

## Channel posterior model

For user k, the simulator uses

\[
H_k\sim\mathcal{CN}(0,C_k),\quad C_k=\beta_k R,
\]

and observes \(\widehat H_k=H_k+E_k\), with

\[
E_k\sim\mathcal{CN}(0,\Sigma_{e,k}),\quad
\Sigma_{e,k}=\beta_k\sigma_{\rm CSI}^2 I.
\]

The implementation samples from the corresponding conditional Gaussian posterior:

\[
\mu_k=C_k(C_k+\Sigma_{e,k})^{-1}\widehat H_k,
\]

\[
C_{k|\widehat H}=C_k-C_k(C_k+\Sigma_{e,k})^{-1}C_k.
\]

The same prior covariance and error model are used to generate the true channel and CSI estimate. The path-loss gains are not normalized to unit mean.

## Calibration design and its limits

Channel calibration uses one independent channel realization as one calibration unit per receiver. For each realization, the residual is maximized component-wise over a pre-declared family of four actions (equal, channel heuristic, deterministic PPO, and random power allocation). Thus four dependent actions from one channel realization do not become four purportedly independent conformal samples.

This block-maximum calibration only covers the stated finite candidate-action family under exchangeability. It does **not** prove coverage for every possible action, an SLSQP-projected action, adaptive policy changes, distribution shift, or simultaneous all-user safety. The evaluation therefore reports empirical lower-bound coverage separately for each evaluated method. Treat this as a diagnostic research design, not a formal safety guarantee.

The PPO state contains the previous PPO command, matching the unshielded training environment. The shield is a downstream action filter. A deployed controller that feeds shielded/applied power back into the policy state should be retrained and separately evaluated with that feedback loop.

## Install and test

From this directory:

```bash
python -m venv .venv
# Activate the environment, then:
python -m pip install -r requirements.txt
python -m compileall -q config.py src tests run_all.py
python -m pytest -q
```

## Run the complete pipeline

The following command trains the demand model and three receiver-specific PPO agents, calibrates channel margins, and evaluates all methods:

```bash
python run_all.py --seeds 10 --blocks 200 --traffic-epochs 100 \
  --calibration-samples 500 --ppo-episodes 250 --ppo-steps 40
```

For a small software integration smoke run (not a research experiment):

```bash
python run_all.py --seeds 2 --blocks 3 --traffic-epochs 2 \
  --calibration-samples 20 --ppo-episodes 2 --ppo-steps 3
```

For a CSI-error and traffic-surge stress test after training and calibration:

```bash
python -m src.evaluate --seeds 10 --blocks 200 \
  --csi-error-multiplier 1.5 --traffic-surge-prob 0.10
```

Outputs are written to `artifacts/` and `results/`; these generated files are excluded from version control. The notebook `ORAN_Energy_Optimization_Version4.ipynb` walks through the same workflow.

## Model assumptions

- Single-cell, narrowband, block-flat uplink; one base station and eight single-antenna users.
- A 3.5 GHz carrier, 20 MHz bandwidth, 10 W sum transmit-power budget, and 100 W illustrative fixed circuit-power assumption.
- Close-in 1 m free-space reference path loss plus a configurable path-loss exponent and log-normal shadowing. Thermal noise is approximated as -94 dBm over 20 MHz (approximately 7 dB noise figure).
- Spatially correlated Rayleigh small-scale fading with an exponential antenna correlation matrix.
- Synthetic traffic, not operator traffic traces. The demand predictor must be compared with persistence and must not be assumed to improve forecasts.
- The power model is illustrative; it is not a measured radio-unit or base-station energy model.

## Research integrity and limitations

- The local SLSQP problem is non-convex; a solver success flag is not a global feasibility proof. On failure, the equal-power fallback respects the sum-power budget only; QoS remains unverified.
- Conformal coverage is marginal and depends on exchangeability. The finite action family, one-step calibration context and time-correlated deployment state do not justify a general guarantee for adaptive shield actions.
- No PPO superiority, energy-saving percentage, deterministic QoS guarantee, live A1/E2 interface, production xApp/rApp, or measured RAN power reduction is claimed.
- Full scientific validation requires independent training/calibration/validation/test seeds, substantially larger sample counts, constrained-RL and optimization baselines, statistical uncertainty analysis, runtime measurements, and robustness checks.

See `docs/V4_RESEARCH_NOVELTY.md` and `docs/V4_VALIDATION_REPORT.md` before making CV, thesis or publication claims.
