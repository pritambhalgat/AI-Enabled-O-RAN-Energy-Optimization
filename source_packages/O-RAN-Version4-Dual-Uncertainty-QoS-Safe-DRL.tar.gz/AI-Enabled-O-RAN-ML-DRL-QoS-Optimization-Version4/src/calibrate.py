import argparse
import os

import numpy as np
import pandas as pd
import torch

from config import Config
from src.data import generate_traffic, load_demand, predict_demand_upper
from src.ppo import ActorCritic, decode_action
from src.radio import actual_rates, generate_channel_pair, heuristic_power, make_state
from src.uncertainty import conformal_margin, posterior_channel_samples, posterior_rate_quantile


def main():
    ap = argparse.ArgumentParser(description="Calibrate receiver-specific channel-rate lower-bound margins")
    ap.add_argument("--samples", type=int, default=None,
                    help="Number of independent channel realizations/calibration units")
    ap.add_argument("--seed", type=int, default=90210)
    a = ap.parse_args()
    c = Config()
    n = int(a.samples or c.channel_calibration_samples)
    if n < 2:
        raise ValueError("At least two independent calibration samples are required")

    predictor, norm = load_demand(c.history, c.n_users, hidden=c.hidden_dim)
    agents = {}
    for rx in c.receiver_names:
        agent = ActorCritic(3 * c.n_users, c.n_users + 1, c.hidden_dim)
        agent.load_state_dict(torch.load(f"artifacts/ppo_{rx}.pt", map_location="cpu", weights_only=True))
        agent.eval()
        agents[rx] = agent

    rng = np.random.default_rng(a.seed)
    # Exactly one score vector per independent channel realization and receiver.
    # Within each realization, take the component-wise maximum residual over a
    # pre-declared finite family of actions. This avoids treating correlated
    # actions on the same channel as independent conformal observations.
    scores = {rx: [] for rx in c.receiver_names}
    for i in range(n):
        traffic_seed = a.seed + 100_003 + i
        traffic = generate_traffic(c.history + 1, c.n_users, traffic_seed)
        _, demand_upper = predict_demand_upper(predictor, norm, traffic[:c.history])
        Htrue, Hest, beta = generate_channel_pair(c, rng, return_beta=True)
        scenarios = posterior_channel_samples(Hest, beta, c, rng)
        p_equal = np.ones(c.n_users) * c.p_max_w / c.n_users
        p_heuristic = heuristic_power(Hest, c)

        for rx in c.receiver_names:
            state = make_state(Hest, demand_upper, p_equal, c)
            with torch.no_grad():
                mu, _, _ = agents[rx](torch.tensor(state, dtype=torch.float32).unsqueeze(0))
                p_ppo = decode_action(mu, c.n_users, c.p_max_w).numpy().ravel()
            p_random = rng.dirichlet(np.ones(c.n_users)) * rng.uniform(0.25, 1.0) * c.p_max_w
            candidate_actions = (p_equal, p_heuristic, p_ppo, p_random)
            action_residuals = []
            for power in candidate_actions:
                predicted_lcb = posterior_rate_quantile(Hest, power, scenarios, c, rx)
                _, realized = actual_rates(Htrue, Hest, power, c, rx)
                action_residuals.append(predicted_lcb - realized)
            block_max_score = np.max(np.asarray(action_residuals), axis=0)
            scores[rx].append(block_max_score)

        if (i + 1) % 50 == 0:
            print(f"Independent channel calibration units: {i + 1}/{n}")

    margins = {
        rx: conformal_margin(np.asarray(scores[rx]), c.channel_calibration_level)
        for rx in c.receiver_names
    }
    os.makedirs("artifacts", exist_ok=True)
    np.savez("artifacts/channel_margins.npz", **margins)

    rows = []
    for rx in c.receiver_names:
        x = np.asarray(scores[rx])
        q = margins[rx]
        coverage = np.mean(x <= q[None, :], axis=0)
        for k in range(c.n_users):
            rows.append({
                "receiver": rx,
                "user": k,
                "margin_mbps": q[k] / 1e6,
                "block_max_calibration_coverage": coverage[k],
                "n_independent_channel_units": x.shape[0],
                "actions_in_block_max": 4,
            })
        print(rx, "block-max margins Mbps", np.round(q / 1e6, 3),
              "empirical block-max coverage", np.round(coverage, 3))
    pd.DataFrame(rows).to_csv("artifacts/channel_calibration_diagnostics.csv", index=False)


if __name__ == "__main__":
    main()
