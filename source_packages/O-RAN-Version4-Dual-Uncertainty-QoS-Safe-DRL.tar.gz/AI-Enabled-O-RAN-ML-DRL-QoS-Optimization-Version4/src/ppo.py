import torch
from torch import nn
from torch.distributions import Normal
class ActorCritic(nn.Module):
    def __init__(self,state_dim,action_dim,hidden=128):
        super().__init__()
        self.body=nn.Sequential(nn.Linear(state_dim,hidden),nn.Tanh(),
                                nn.Linear(hidden,hidden),nn.Tanh())
        self.mu=nn.Linear(hidden,action_dim)
        self.log_std=nn.Parameter(torch.full((action_dim,),-.6))
        self.value=nn.Linear(hidden,1)
    def forward(self,s):
        z=self.body(s)
        return self.mu(z),self.log_std.expand(s.shape[0],-1),self.value(z).squeeze(-1)
    def sample(self,s):
        mu,ls,v=self(s); d=Normal(mu,ls.exp()); a=d.sample()
        return a,d.log_prob(a).sum(-1),v
    def evaluate(self,s,a):
        mu,ls,v=self(s); d=Normal(mu,ls.exp())
        return d.log_prob(a).sum(-1),d.entropy().sum(-1),v

def decode_action(raw,K,pmax):
    share=torch.softmax(raw[...,:K],dim=-1)
    fraction=torch.sigmoid(raw[...,K:K+1])
    return share*fraction*pmax

def generalized_advantage(rewards,values,dones,gamma,lam):
    adv=torch.zeros_like(rewards); last=0.
    for t in reversed(range(len(rewards))):
        nextv=0. if (t==len(rewards)-1 or dones[t]) else values[t+1]
        alive=0. if dones[t] else 1.
        delta=rewards[t]+gamma*nextv-values[t]
        last=delta+gamma*lam*alive*last; adv[t]=last
    return adv,adv+values
