import numpy as np

RECEIVERS = ("MRC", "ZF", "MMSE")


def spatial_correlation(n_antennas, coefficient=0.2):
    idx = np.arange(n_antennas)
    return coefficient ** np.abs(idx[:, None] - idx[None, :])


def generate_channel_pair(cfg, rng, return_beta=False):
    """Generate H~CN(0,beta_k R) and Hhat=H+E.

    The large-scale gain uses a close-in 1 m free-space reference loss plus
    the configured path-loss exponent and log-normal shadowing. CSI error is
    spatially white with variance csi_error_std**2 * beta_k per coefficient.
    """
    K, M = cfg.n_users, cfg.n_antennas
    distance = rng.uniform(35.0, 250.0, K)
    c = 299_792_458.0
    fspl_1m_db = 20.0 * np.log10(4.0 * np.pi * cfg.carrier_frequency_hz / c)
    loss_db = (fspl_1m_db
               + 10.0 * cfg.pathloss_exponent * np.log10(distance)
               + rng.normal(0.0, cfg.shadow_std_db, K))
    beta = 10.0 ** (-loss_db / 10.0)

    R = spatial_correlation(M)
    eigvals, eigvecs = np.linalg.eigh(R)
    Rs = eigvecs @ np.diag(np.sqrt(np.maximum(eigvals, 0.0))) @ eigvecs.conj().T
    z = (rng.normal(size=(M, K)) + 1j * rng.normal(size=(M, K))) / np.sqrt(2.0)
    H = Rs @ z * np.sqrt(beta)[None, :]
    e = (rng.normal(size=(M, K)) + 1j * rng.normal(size=(M, K))) / np.sqrt(2.0)
    E = cfg.csi_error_std * e * np.sqrt(beta)[None, :]
    Hest = H + E
    if return_beta:
        return H, Hest, beta
    return H, Hest


def make_combiner(Hest, p, cfg, receiver):
    M, K = Hest.shape
    gram = Hest.conj().T @ Hest
    scale = max(float(np.real(np.trace(gram))) / max(K, 1), 1e-30)
    load = 1e-8 * scale
    receiver = receiver.upper()
    if receiver == "MRC":
        return Hest.conj().T
    if receiver == "ZF":
        return np.linalg.solve(gram + load * np.eye(K), Hest.conj().T)
    if receiver == "MMSE":
        Ryy = (Hest * np.asarray(p)[None, :]) @ Hest.conj().T + cfg.noise_power * np.eye(M)
        return np.linalg.solve(Ryy, Hest).conj().T
    raise ValueError("receiver must be MRC, ZF or MMSE")


def rates_with_combiner(Heval, W, p, cfg):
    G = W @ Heval
    gains = np.abs(G) ** 2
    desired = np.asarray(p) * np.diag(gains)
    total = gains @ np.asarray(p)
    interf = np.maximum(total - desired, 0.0)
    noise = cfg.noise_power * np.sum(np.abs(W) ** 2, axis=1)
    sinr = desired / np.maximum(interf + noise, 1e-30)
    return sinr, cfg.bandwidth_hz * np.log2(1.0 + sinr)


def actual_rates(Htrue, Hest, p, cfg, receiver):
    W = make_combiner(Hest, p, cfg, receiver)
    return rates_with_combiner(Htrue, W, p, cfg)


def system_metrics(Htrue, Hest, p, cfg, receiver, demand):
    sinr, rates = actual_rates(Htrue, Hest, p, cfg, receiver)
    ptotal = cfg.fixed_power_w + float(np.sum(p)) / cfg.pa_efficiency
    sumrate = float(rates.sum())
    rmin = cfg.min_rate_base_bps + cfg.min_rate_span_bps * np.asarray(demand)
    sat = float(np.mean(rates >= rmin))
    fairness = float(sumrate**2 / (cfg.n_users * np.sum(rates**2) + 1e-30))
    return {
        "rates": rates,
        "sinr": sinr,
        "sum_rate_bps": sumrate,
        "ee_bit_j": sumrate / max(ptotal, 1e-30),
        "total_power_w": ptotal,
        "qos_satisfaction": sat,
        "outage_fraction": 1.0 - sat,
        "mean_shortfall_bps": float(np.mean(np.maximum(rmin - rates, 0.0))),
        "jain_fairness": fairness,
    }


def make_state(Hest, demand_upper, p_prev, cfg):
    gains = np.mean(np.abs(Hest) ** 2, axis=0)
    lg = np.log10(gains + 1e-30)
    lg = (lg - lg.mean()) / (lg.std() + 1e-8)
    d = np.asarray(demand_upper) / (np.mean(demand_upper) + 1e-8)
    pp = np.asarray(p_prev) / (cfg.p_max_w / cfg.n_users)
    return np.concatenate([lg, d, pp]).astype(np.float32)


def heuristic_power(Hest, cfg):
    gains = np.sum(np.abs(Hest) ** 2, axis=0)
    weights = 0.05 / cfg.n_users + 0.95 * gains / (gains.sum() + 1e-30)
    return cfg.p_max_w * weights / weights.sum()
