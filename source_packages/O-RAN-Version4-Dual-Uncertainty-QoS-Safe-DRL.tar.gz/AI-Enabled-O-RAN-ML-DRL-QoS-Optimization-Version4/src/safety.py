import numpy as np
from scipy.optimize import minimize

from src.uncertainty import posterior_channel_samples, posterior_rate_quantile


def project_power(Hest, p_proposed, demand_target, cfg, receiver, margins, rng,
                  calibrated=True, maxiter=None, posterior_scenarios=None, beta=None):
    """Nearest-power SLSQP projection; solver success is not a QoS guarantee."""
    p0 = np.clip(np.asarray(p_proposed, dtype=float), 0.0, cfg.p_max_w)
    if posterior_scenarios is None:
        if beta is None:
            raise ValueError("beta is required to sample the conditional channel posterior")
        scenarios = posterior_channel_samples(Hest, beta, cfg, rng)
    else:
        scenarios = posterior_scenarios
    target = cfg.min_rate_base_bps + cfg.min_rate_span_bps * np.asarray(demand_target)
    margin = np.asarray(margins[receiver]) if calibrated else np.zeros(cfg.n_users)

    def lcb(power):
        return posterior_rate_quantile(Hest, power, scenarios, cfg, receiver) - margin

    def objective(power):
        return float(np.sum((power - p0) ** 2))

    constraints = [
        {"type": "ineq", "fun": lambda power: cfg.p_max_w - float(np.sum(power))},
        {"type": "ineq", "fun": lambda power: lcb(power) - target},
    ]
    starts = [p0, np.ones(cfg.n_users) * cfg.p_max_w / cfg.n_users]
    feasible = []
    for x0 in starts:
        result = minimize(
            objective, x0, method="SLSQP",
            bounds=[(0.0, cfg.p_max_w)] * cfg.n_users,
            constraints=constraints,
            options={"maxiter": int(maxiter or cfg.projection_maxiter), "ftol": 1e-8},
        )
        power = np.clip(result.x, 0.0, cfg.p_max_w)
        valid = (bool(result.success)
                 and power.sum() <= cfg.p_max_w + 1e-5
                 and np.all(lcb(power) >= target - 1e-2))
        if valid:
            feasible.append((objective(power), power))
    if feasible:
        return min(feasible, key=lambda item: item[0])[1], True

    # This fallback preserves the sum-power budget only. QoS is unverified.
    return np.ones(cfg.n_users) * cfg.p_max_w / cfg.n_users, False
