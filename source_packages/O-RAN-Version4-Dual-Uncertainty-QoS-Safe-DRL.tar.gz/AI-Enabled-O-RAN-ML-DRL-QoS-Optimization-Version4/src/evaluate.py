import argparse
import os

import numpy as np
import pandas as pd
import torch
from scipy.stats import t

from config import Config
from src.data import generate_traffic, load_demand, predict_demand_upper
from src.ppo import ActorCritic, decode_action
from src.radio import (actual_rates, generate_channel_pair, heuristic_power,
                       make_state, system_metrics)
from src.safety import project_power
from src.uncertainty import posterior_channel_samples, posterior_rate_quantile


def summarize(df):
    cols = ["sum_rate_mbps", "ee_mbps_per_w", "qos_satisfaction", "outage_fraction",
            "mean_shortfall_mbps", "total_power_w", "jain_fairness", "shield_success"]
    rows = []
    for (scenario, rx, method), group in df.groupby(["scenario", "receiver", "method"]):
        row = {"scenario": scenario, "receiver": rx, "method": method}
        for col in cols:
            vals = group.groupby("seed")[col].mean().to_numpy()
            n = len(vals)
            mean = float(vals.mean())
            sd = float(vals.std(ddof=1)) if n > 1 else float("nan")
            half = float(t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
            row[col + "_mean"] = mean
            row[col + "_sd_seed"] = sd
            row[col + "_ci95_low"] = mean - half if n > 1 else float("nan")
            row[col + "_ci95_high"] = mean + half if n > 1 else float("nan")
        row["n_seeds"] = group.seed.nunique()
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--blocks", type=int, default=50)
    parser.add_argument("--seed-start", type=int, default=7000)
    parser.add_argument("--output", default="results")
    parser.add_argument("--csi-error-multiplier", type=float, default=1.0)
    parser.add_argument("--traffic-surge-prob", type=float, default=0.0)
    parser.add_argument("--traffic-surge-magnitude", type=float, default=0.30)
    a = parser.parse_args()
    if a.seeds < 2 or a.blocks < 1:
        raise ValueError("Use at least two seeds and one block.")
    c = Config()
    if a.csi_error_multiplier <= 0 or not 0 <= a.traffic_surge_prob <= 1:
        raise ValueError("CSI multiplier must be positive and surge probability in [0,1].")
    c.csi_error_std *= a.csi_error_multiplier
    scenario_name = f"csi{a.csi_error_multiplier:g}_surge{a.traffic_surge_prob:g}"

    model, norm = load_demand(c.history, c.n_users, hidden=c.hidden_dim)
    margins = dict(np.load("artifacts/channel_margins.npz"))
    agents = {}
    for rx in c.receiver_names:
        agent = ActorCritic(3 * c.n_users, c.n_users + 1, c.hidden_dim)
        agent.load_state_dict(torch.load(f"artifacts/ppo_{rx}.pt", map_location="cpu", weights_only=True))
        agent.eval()
        agents[rx] = agent

    os.makedirs(a.output, exist_ok=True)
    rows = []
    traffic_coverage_rows = []
    channel_coverage_rows = []

    for seed in range(a.seed_start, a.seed_start + a.seeds):
        rng = np.random.default_rng(seed)
        trace = generate_traffic(a.blocks + c.history, c.n_users, seed + 101)
        previous = {rx: np.ones(c.n_users) * c.p_max_w / c.n_users for rx in c.receiver_names}
        traffic_hits = []
        channel_hits = {rx: {method: [] for method in (
            "equal", "channel_heuristic", "PPO_raw",
            "PPO_uncalibrated_shield", "PPO_dual_calibrated_shield")}
            for rx in c.receiver_names}

        for block in range(a.blocks):
            demand_point, demand_upper = predict_demand_upper(model, norm, trace[block:block + c.history])
            actual_demand = trace[block + c.history].copy()
            if a.traffic_surge_prob > 0:
                surge = rng.random(c.n_users) < a.traffic_surge_prob
                actual_demand = np.clip(actual_demand + surge * a.traffic_surge_magnitude, 0, 1)
            traffic_hits.append(actual_demand <= demand_upper)

            Htrue, Hest, beta = generate_channel_pair(c, rng, return_beta=True)
            equal = np.ones(c.n_users) * c.p_max_w / c.n_users
            heuristic = heuristic_power(Hest, c)
            scenarios = posterior_channel_samples(Hest, beta, c, rng)

            for rx in c.receiver_names:
                state = make_state(Hest, demand_upper, previous[rx], c)
                with torch.no_grad():
                    mu, _, _ = agents[rx](torch.tensor(state, dtype=torch.float32).unsqueeze(0))
                    p_raw = decode_action(mu, c.n_users, c.p_max_w).numpy().ravel()

                p_uncal, ok_uncal = project_power(
                    Hest, p_raw, demand_point, c, rx, margins, rng,
                    calibrated=False, posterior_scenarios=scenarios)
                p_cal, ok_cal = project_power(
                    Hest, p_raw, demand_upper, c, rx, margins, rng,
                    calibrated=True, posterior_scenarios=scenarios)
                methods = {
                    "equal": (equal, True),
                    "channel_heuristic": (heuristic, True),
                    "PPO_raw": (p_raw, True),
                    "PPO_uncalibrated_shield": (p_uncal, ok_uncal),
                    "PPO_dual_calibrated_shield": (p_cal, ok_cal),
                }

                for method, (power, solver_ok) in methods.items():
                    predicted_lcb = posterior_rate_quantile(Hest, power, scenarios, c, rx) - np.asarray(margins[rx])
                    _, realized_rates = actual_rates(Htrue, Hest, power, c, rx)
                    channel_hits[rx][method].append(predicted_lcb <= realized_rates)
                    metrics = system_metrics(Htrue, Hest, power, c, rx, actual_demand)
                    rows.append({
                        "seed": seed, "block": block, "scenario": scenario_name,
                        "receiver": rx, "method": method,
                        "sum_rate_mbps": metrics["sum_rate_bps"] / 1e6,
                        "ee_mbps_per_w": metrics["ee_bit_j"] / 1e6,
                        "qos_satisfaction": metrics["qos_satisfaction"],
                        "outage_fraction": metrics["outage_fraction"],
                        "mean_shortfall_mbps": metrics["mean_shortfall_bps"] / 1e6,
                        "total_power_w": metrics["total_power_w"],
                        "jain_fairness": metrics["jain_fairness"],
                        "power_budget_used": float(np.sum(power) / c.p_max_w),
                        "shield_success": float(solver_ok),
                    })

                # The PPO state feature is explicitly the previous PPO command,
                # matching the unshielded PPO training environment. The shield
                # is a downstream action filter; feedback of applied shield power
                # would require retraining the policy with the shield in-loop.
                previous[rx] = p_raw

        traffic_array = np.asarray(traffic_hits)
        for user in range(c.n_users):
            traffic_coverage_rows.append({
                "seed": seed, "user": user,
                "upper_bound_coverage": float(np.mean(traffic_array[:, user])),
            })
        for rx in c.receiver_names:
            for method, hits in channel_hits[rx].items():
                hit_array = np.asarray(hits)
                for user in range(c.n_users):
                    channel_coverage_rows.append({
                        "seed": seed, "receiver": rx, "method": method, "user": user,
                        "lower_rate_bound_coverage": float(np.mean(hit_array[:, user])),
                    })
        print("Completed test seed", seed)

    df = pd.DataFrame(rows)
    summary = summarize(df)
    df.to_csv(os.path.join(a.output, "per_seed.csv"), index=False)
    summary.to_csv(os.path.join(a.output, "summary_ci95.csv"), index=False)
    pd.DataFrame(traffic_coverage_rows).to_csv(
        os.path.join(a.output, "traffic_bound_coverage.csv"), index=False)
    pd.DataFrame(channel_coverage_rows).to_csv(
        os.path.join(a.output, "channel_lcb_coverage.csv"), index=False)
    print(summary.to_string(index=False))
    print("Saved traffic-bound and method-specific channel-LCB coverage diagnostics for", scenario_name)


if __name__ == "__main__":
    main()
