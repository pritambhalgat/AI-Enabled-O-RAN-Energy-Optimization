import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

def generate_traffic(n_steps,n_users,seed=0):
    """Synthetic persistent demand traces in [0,1], not operator data."""
    rng=np.random.default_rng(seed)
    phases=rng.uniform(0,2*np.pi,n_users)
    base=rng.uniform(.25,.65,n_users)
    state=base.copy()
    series=np.zeros((n_steps,n_users),np.float32)
    for i in range(n_steps):
        seasonal=.22*np.sin(2*np.pi*i/64+phases)
        state=np.clip(.90*state+.10*(base+seasonal)+rng.normal(0,.035,n_users),.03,1.)
        series[i]=state
    return series

def make_windows(series,history):
    X=[]; y=[]
    for t in range(history,len(series)):
        X.append(series[t-history:t].reshape(-1)); y.append(series[t])
    return np.asarray(X,np.float32),np.asarray(y,np.float32)

def finite_sample_quantile(scores,level):
    scores=np.asarray(scores,float)
    n=scores.shape[0]
    if n<2: raise ValueError("At least two calibration samples required")
    rank=min(max(int(np.ceil((n+1)*level)),1),n)
    return np.sort(scores,axis=0)[rank-1]

class DemandMLP(nn.Module):
    def __init__(self,input_dim,n_users,hidden=128):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(input_dim,hidden),nn.ReLU(),
             nn.Linear(hidden,64),nn.ReLU(),nn.Linear(64,n_users))
    def forward(self,x): return self.net(x)


def _independent_windows(n_samples,history,n_users,seed):
    """Independent short AR trajectories used to build exchangeable supervised samples."""
    rng=np.random.default_rng(seed)
    base=rng.uniform(.25,.65,(n_samples,n_users))
    phase=rng.uniform(0,2*np.pi,(n_samples,n_users))
    state=base.copy()
    windows=np.zeros((n_samples,history+1,n_users),np.float32)
    for t in range(history+1):
        seasonal=.22*np.sin(2*np.pi*t/64+phase)
        state=np.clip(.90*state+.10*(base+seasonal)
                      +rng.normal(0,.035,(n_samples,n_users)),.03,1.)
        windows[:,t,:]=state
    return windows[:,:history,:].reshape(n_samples,-1),windows[:,history,:]

def train_demand(history=8,n_users=8,seed=71,epochs=20,hidden=128):
    torch.manual_seed(seed); np.random.seed(seed)
    Xtr,Ytr=_independent_windows(12000,history,n_users,seed)
    Xcal,Ycal=_independent_windows(3000,history,n_users,seed+1)
    Xtest,Ytest=_independent_windows(3000,history,n_users,seed+2)
    xm=float(Xtr.mean()); xs=float(Xtr.std()+1e-8)
    ym=Ytr.mean(0); ys=Ytr.std(0)+1e-8
    Xn=(Xtr-xm)/xs; Yn=(Ytr-ym)/ys
    model=DemandMLP(history*n_users,n_users,hidden)
    loader=DataLoader(TensorDataset(torch.tensor(Xn),torch.tensor(Yn)),batch_size=128,shuffle=True)
    opt=torch.optim.Adam(model.parameters(),lr=1e-3); lossfn=nn.MSELoss()
    for ep in range(epochs):
        model.train(); losses=[]
        for xb,yb in loader:
            opt.zero_grad(); loss=lossfn(model(xb),yb); loss.backward(); opt.step()
            losses.append(float(loss.item()))
        if (ep+1)%5==0: print(f"Demand MLP {ep+1}/{epochs}: MSE={np.mean(losses):.5f}")
    model.eval()
    with torch.no_grad():
        pc=model(torch.tensor((Xcal-xm)/xs)).numpy()*ys+ym
        pt=model(torch.tensor((Xtest-xm)/xs)).numpy()*ys+ym
    q=finite_sample_quantile(Ycal-pc,.95)
    mae=float(np.mean(np.abs(pt-Ytest)))
    persistence=float(np.mean(np.abs(Xtest.reshape(-1,history,n_users)[:,-1,:]-Ytest)))
    coverage=np.mean(Ytest<=np.clip(pt+q,0,1),axis=0)
    norm={"x_mean":xm,"x_std":xs,"y_mean":ym,"y_std":ys,"q_user":q}
    return model,norm,mae,persistence,coverage

def predict_demand_upper(model,norm,history_window):
    x=np.asarray(history_window,np.float32).reshape(1,-1)
    with torch.no_grad():
        pn=model(torch.tensor((x-float(norm["x_mean"]))/float(norm["x_std"]))).numpy()[0]
    point=np.clip(pn*np.asarray(norm["y_std"])+np.asarray(norm["y_mean"]),0,1)
    upper=np.clip(point+np.asarray(norm["q_user"]),0,1)
    return point,upper

def save_demand(model,norm,directory="artifacts"):
    import os
    os.makedirs(directory,exist_ok=True)
    torch.save(model.state_dict(),os.path.join(directory,"demand_mlp.pt"))
    np.savez(os.path.join(directory,"demand_calibration.npz"),**norm)

def load_demand(history,n_users,directory="artifacts",hidden=128):
    import os
    model=DemandMLP(history*n_users,n_users,hidden)
    model.load_state_dict(torch.load(os.path.join(directory,"demand_mlp.pt"),map_location="cpu",weights_only=True))
    model.eval()
    return model,dict(np.load(os.path.join(directory,"demand_calibration.npz")))
