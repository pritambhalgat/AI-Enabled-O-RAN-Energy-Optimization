import argparse
from config import Config
from src.data import train_demand,save_demand

def main():
    p=argparse.ArgumentParser(); p.add_argument("--epochs",type=int,default=20); a=p.parse_args()
    c=Config()
    model,norm,mae,persist,coverage=train_demand(c.history,c.n_users,epochs=a.epochs,hidden=c.hidden_dim)
    save_demand(model,norm)
    print(f"MLP MAE={mae:.6f}; persistence MAE={persist:.6f}")
    print("One-sided conformal demand coverage by user:",coverage)
if __name__=="__main__": main()
