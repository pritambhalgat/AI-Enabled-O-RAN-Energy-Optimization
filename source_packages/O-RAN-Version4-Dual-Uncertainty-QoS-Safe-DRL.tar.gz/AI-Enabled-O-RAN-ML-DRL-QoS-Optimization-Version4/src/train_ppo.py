import argparse,os,numpy as np,torch
from config import Config
from src.data import generate_traffic,load_demand,predict_demand_upper
from src.radio import generate_channel_pair,make_state,system_metrics
from src.ppo import ActorCritic,decode_action,generalized_advantage

def train_receiver(receiver,cfg,episodes=None,steps=None,seed=55):
    episodes=int(episodes or cfg.ppo_episodes); steps=int(steps or cfg.steps_per_episode)
    np.random.seed(seed); torch.manual_seed(seed)
    model,norm=load_demand(cfg.history,cfg.n_users,hidden=cfg.hidden_dim)
    trace=generate_traffic(episodes*steps+cfg.history,cfg.n_users,seed+7)
    agent=ActorCritic(3*cfg.n_users,cfg.n_users+1,cfg.hidden_dim)
    opt=torch.optim.Adam(agent.parameters(),lr=cfg.learning_rate)
    rng=np.random.default_rng(seed); idx=cfg.history
    for ep in range(episodes):
        S=[]; A=[]; LP=[]; V=[]; R=[]; D=[]
        prev=np.ones(cfg.n_users)*cfg.p_max_w/cfg.n_users
        er=[]
        for _ in range(steps):
            dpoint,dup=predict_demand_upper(model,norm,trace[idx-cfg.history:idx])
            Htrue,Hest=generate_channel_pair(cfg,rng)
            state=make_state(Hest,dup,prev,cfg); st=torch.tensor(state).unsqueeze(0)
            with torch.no_grad():
                raw,lp,val=agent.sample(st)
                power=decode_action(raw,cfg.n_users,cfg.p_max_w).squeeze(0).numpy()
            m=system_metrics(Htrue,Hest,power,cfg,receiver,trace[idx])
            reward=(.4*m["ee_bit_j"]/1e6+.4*m["sum_rate_bps"]/(cfg.n_users*50e6)
                    -3*m["outage_fraction"]-.1*(1-m["jain_fairness"])
                    -.02*np.mean(np.abs(power-prev))/cfg.p_max_w)
            S.append(state); A.append(raw.squeeze(0).numpy()); LP.append(lp.item()); V.append(val.item())
            R.append(float(reward)); D.append(0.); er.append(reward)
            prev=power; idx+=1
        D[-1]=1.
        S=torch.tensor(np.asarray(S),dtype=torch.float32); A=torch.tensor(np.asarray(A),dtype=torch.float32)
        LP=torch.tensor(LP,dtype=torch.float32); V=torch.tensor(V,dtype=torch.float32)
        R=torch.tensor(R,dtype=torch.float32); D=torch.tensor(D,dtype=torch.float32)
        adv,ret=generalized_advantage(R,V,D,cfg.gamma,cfg.gae_lambda)
        adv=(adv-adv.mean())/(adv.std()+1e-8)
        for _ in range(cfg.ppo_epochs):
            order=np.random.permutation(len(S))
            for start in range(0,len(S),cfg.minibatch_size):
                ix=order[start:start+cfg.minibatch_size]
                lp,ent,val=agent.evaluate(S[ix],A[ix]); ratio=torch.exp(lp-LP[ix])
                actor=-torch.min(ratio*adv[ix],torch.clamp(ratio,1-cfg.clip_epsilon,1+cfg.clip_epsilon)*adv[ix]).mean()
                critic=.5*((val-ret[ix])**2).mean()
                loss=actor+cfg.value_coef*critic-cfg.entropy_coef*ent.mean()
                opt.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(agent.parameters(),.5); opt.step()
        if (ep+1)%25==0: print(f"{receiver} episode {ep+1}/{episodes}; reward={np.mean(er):.4f}")
    os.makedirs("artifacts",exist_ok=True); path=f"artifacts/ppo_{receiver}.pt"
    torch.save(agent.state_dict(),path); return path

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--receiver",choices=("MRC","ZF","MMSE"),required=True)
    p.add_argument("--episodes",type=int,default=None); p.add_argument("--steps",type=int,default=None)
    p.add_argument("--seed",type=int,default=55); a=p.parse_args()
    print("Saved",train_receiver(a.receiver,Config(),a.episodes,a.steps,a.seed))
if __name__=="__main__": main()
