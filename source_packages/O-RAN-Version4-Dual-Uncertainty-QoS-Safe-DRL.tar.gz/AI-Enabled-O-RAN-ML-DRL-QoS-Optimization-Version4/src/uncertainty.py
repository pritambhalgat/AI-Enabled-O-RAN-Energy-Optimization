import numpy as np

from src.radio import spatial_correlation


def posterior_channel_parameters(Hest, beta, cfg):
    """Return exact complex-Gaussian H|Hhat means and covariances.

    Prior: H_k ~ CN(0, beta_k R).
    Observation: Hhat_k = H_k + E_k, E_k ~ CN(0, beta_k*sigma_rel^2 I).
    Therefore the posterior is Gaussian with the standard linear-Gaussian
    conditional mean and covariance. This matches generate_channel_pair().
    """
    Hest = np.asarray(Hest, dtype=np.complex128)
    beta = np.asarray(beta, dtype=float)
    M, K = Hest.shape
    if beta.shape != (K,) or np.any(beta <= 0.0):
        raise ValueError("beta must contain one positive large-scale gain per user")

    R = spatial_correlation(M)
    means = np.empty_like(Hest)
    covariances = np.empty((K, M, M), dtype=np.complex128)
    eye = np.eye(M)
    for k in range(K):
        C = beta[k] * R
        C_e = beta[k] * cfg.csi_error_std**2 * eye
        S = C + C_e
        gain = np.linalg.solve(S.T, C.T).T
        means[:, k] = gain @ Hest[:, k]
        cov = C - gain @ C
        cov = 0.5 * (cov + cov.conj().T)
        covariances[k] = cov
    return means, covariances


def posterior_channel_samples(Hest, beta, cfg, rng, n_samples=None):
    """Draw samples from the simulator-consistent posterior p(H|Hhat,beta)."""
    n = int(n_samples or cfg.posterior_samples)
    if n < 1:
        raise ValueError("n_samples must be positive")
    means, covariances = posterior_channel_parameters(Hest, beta, cfg)
    M, K = means.shape
    samples = np.empty((n, M, K), dtype=np.complex128)
    for k in range(K):
        vals, vecs = np.linalg.eigh(covariances[k])
        L = vecs @ np.diag(np.sqrt(np.maximum(vals, 0.0)))
        z = (rng.normal(size=(M, n)) + 1j * rng.normal(size=(M, n))) / np.sqrt(2.0)
        samples[:, :, k] = (means[:, k, None] + L @ z).T
    return samples


def posterior_rate_quantile(Hest, p, scenarios, cfg, receiver, quantile=None):
    from src.radio import make_combiner, rates_with_combiner

    W = make_combiner(Hest, p, cfg, receiver)
    q = cfg.posterior_quantile if quantile is None else quantile
    vals = []
    for Hs in scenarios:
        _, rates = rates_with_combiner(Hs, W, p, cfg)
        vals.append(rates)
    return np.quantile(np.asarray(vals), q, axis=0)


def conformal_margin(scores, level):
    """Finite-sample upper residual quantile along axis 0."""
    x = np.asarray(scores, dtype=float)
    if x.ndim < 1 or x.shape[0] < 2:
        raise ValueError("At least two independent calibration units are required")
    if not 0.0 < level < 1.0:
        raise ValueError("level must be strictly between zero and one")
    n = x.shape[0]
    rank = min(int(np.ceil((n + 1) * level)), n)
    return np.maximum(0.0, np.sort(x, axis=0)[rank - 1])
