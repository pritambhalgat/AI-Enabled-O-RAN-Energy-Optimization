from dataclasses import dataclass


@dataclass
class Config:
    n_antennas: int = 64
    n_users: int = 8
    bandwidth_hz: float = 20e6
    # Thermal noise over 20 MHz with approximately 7 dB receiver noise figure.
    # -174 dBm/Hz + 10*log10(20 MHz) + 7 dB ~= -94 dBm.
    noise_power: float = 3.98e-13
    p_max_w: float = 10.0
    pa_efficiency: float = 0.40
    fixed_power_w: float = 100.0  # Illustrative circuit-power assumption.
    carrier_frequency_hz: float = 3.5e9
    csi_error_std: float = 0.12  # Relative per-complex-coefficient CSI error std.
    pathloss_exponent: float = 3.5
    shadow_std_db: float = 6.0
    history: int = 8
    min_rate_base_bps: float = 5e6
    min_rate_span_bps: float = 25e6
    traffic_calibration_level: float = 0.95
    channel_calibration_level: float = 0.95
    posterior_quantile: float = 0.10
    posterior_samples: int = 64
    channel_calibration_samples: int = 240
    ppo_episodes: int = 250
    steps_per_episode: int = 40
    hidden_dim: int = 128
    learning_rate: float = 3e-4
    gamma: float = 0.98
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.20
    ppo_epochs: int = 6
    minibatch_size: int = 128
    entropy_coef: float = 0.005
    value_coef: float = 0.5
    projection_maxiter: int = 100

    @property
    def receiver_names(self):
        return ("MRC", "ZF", "MMSE")
