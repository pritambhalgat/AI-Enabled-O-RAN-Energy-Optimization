# Version 4 research rationale and candidate contribution

## Working title

**Dual-Calibrated QoS-Aware Reinforcement Learning for Receiver-Aware O-RAN Uplink Power Control under Traffic and CSI Uncertainty**

## Research question

Can a receiver-aware PPO power-allocation policy, filtered by a calibrated action shield, reduce user-level QoS violations under uncertain traffic demand and imperfect CSI while accounting for throughput, power and fairness costs?

## Implemented components

1. **Traffic-demand uncertainty.** A PyTorch MLP forecasts normalized synthetic per-user demand. One-sided split-conformal residual quantiles form conservative demand upper estimates. Persistence is retained as an essential baseline.
2. **Conditional channel uncertainty.** For each user, the simulated channel prior is \(H_k\sim\mathcal{CN}(0,C_k)\), with \(C_k=\beta_kR\). The CSI observation is \(\widehat H_k=H_k+E_k\), where \(E_k\sim\mathcal{CN}(0,\beta_k\sigma_{CSI}^2I)\). The code samples from the analytical complex-Gaussian conditional distribution:

   \[
   \mu_k=C_k(C_k+\Sigma_{e,k})^{-1}\widehat H_k,
   \]
   \[
   C_{k|\widehat H}=C_k-C_k(C_k+\Sigma_{e,k})^{-1}C_k.
   \]

   This replaces the earlier heuristic perturbation \(H_s=\widehat H+N(0,\sigma^2I)\), which was not derived as \(p(H|\widehat H)\).
3. **Receiver-aware lower-tail rate estimates.** MRC, ZF and MMSE combining are evaluated using post-combining multi-user interference and receiver noise enhancement. Lower-tail rate quantiles are computed over posterior channel samples.
4. **Channel calibration.** For each receiver, one independent channel realization contributes one calibration score vector. The score is the component-wise maximum over a fixed set of four power-allocation actions: equal, channel heuristic, deterministic PPO and random allocation. This avoids pseudo-replication from counting multiple dependent actions on the same channel draw as independent calibration observations.
5. **Action filtering.** An SLSQP nearest-action projection attempts to meet the calibrated lower-rate targets and the sum-power constraint. It is a local non-convex optimization, not a guaranteed feasible or globally optimal solution.
6. **Evaluation.** Raw PPO, uncalibrated shielding, calibrated shielding, equal allocation and channel-aware heuristic allocation are compared. Method-specific lower-bound coverage, QoS satisfaction, outage, rate shortfall, throughput, assumed energy efficiency, Jain fairness, total power, solver success and seed-level confidence intervals are recorded.

## Formulation

For user \(k\), the demand upper estimate is

\[
d_{upper,k}=\operatorname{clip}(\hat d_k+q_{d,k},0,1),
\]

and the corresponding QoS target is

\[
R_{min,k}=R_{base}+R_{span}d_{upper,k}.
\]

For receiver \(r\), let \(L_{k,r}(p)\) be a lower posterior quantile of the user rate under a candidate power vector \(p\). A calibrated margin \(q_{c,k,r}\) is subtracted to form

\[
LCB_{k,r}(p)=L_{k,r}(p)-q_{c,k,r}.
\]

The runtime shield attempts to solve

\[
\min_p\;\|p-p_{PPO}\|_2^2
\]

subject to

\[
\sum_kp_k\le P_{max},\quad p_k\ge0,\quad
LCB_{k,r}(p)\ge R_{min,k}.
\]

The interference-coupled rate constraints are non-convex. SLSQP is a local solver. A failed projection falls back to equal power, which preserves the sum-power budget but does not establish QoS satisfaction.

## Calibration assumptions and limits

The current channel calibration uses a component-wise block maximum across four predefined action families, producing one score vector per independent channel realization and receiver. Its finite-sample interpretation is limited to that predeclared action family under exchangeability. It does not provide a theorem for arbitrary projected actions, adaptive policy shifts, temporal dependence, distribution shifts or simultaneous all-user coverage. The shield's actual selected power vectors are therefore evaluated empirically on held-out seeds; coverage must not be described as guaranteed.

The PPO state uses the previous PPO command, consistent with the unshielded training environment. The shield is applied downstream. Feeding shielded/applied power into subsequent policy states would change the control loop and requires retraining and revalidation.

## Current candidate contribution (not a novelty claim)

The candidate research direction is the joint study of (i) demand uncertainty, (ii) simulator-consistent conditional CSI uncertainty, (iii) receiver-conditioned lower-tail rates, and (iv) a QoS-constrained nearest-action filter for PPO power commands. QoS-aware O-RAN DRL, safe wireless RL and conformal prediction already exist; novelty cannot be inferred from combining these keywords. A systematic literature review and rigorous baselines are required before claiming an original contribution.

## Research questions for a full study

- Does the calibrated shield reduce per-user QoS violations relative to raw PPO and an uncalibrated shield on held-out seeds?
- Does the block-maximum calibration remain informative for actions produced by the shield, or are action-conditional/trajectory-level calibration methods needed?
- How do lower-bound coverage and projection failure vary across MRC, ZF and MMSE?
- What throughput, energy-efficiency and fairness costs accompany more conservative QoS enforcement?
- How sensitive are results to CSI error, traffic bursts, path loss, shadowing, user geometry and heavy-tailed channel errors?
- How does the approach compare with constrained PPO/Lagrangian methods, safe RL baselines and numerical optimization?

## Related work to review

- Yan et al., “Near-Real-Time Resource Slicing for QoS Optimization in 5G O-RAN using Deep Reinforcement Learning,” arXiv:2509.14343 (2025), https://arxiv.org/abs/2509.14343
- “RSLAQ—A Robust SLA-Driven 6G O-RAN QoS xApp Using Deep Reinforcement Learning,” IEEE Transactions on Mobile Computing (2026), DOI:10.1109/TMC.2026.3666787
- Peng et al., “Enabling Safety-Critical Wireless Communications via Safe Reinforcement Learning,” arXiv:2604.17032 (2026)
- “Deep Reinforcement Learning Based Subchannel Selection and Power Allocation in Wireless Networks with Imperfect CSI,” IEEE VTC 2023, DOI:10.1109/VTC2023-Spring57618.2023.10199481
- Cohen et al., “Calibrating AI Models for Wireless Communications via Conformal Prediction,” IEEE TMLCN (2023)

The literature list is an initial reading list, not a completed systematic review.
