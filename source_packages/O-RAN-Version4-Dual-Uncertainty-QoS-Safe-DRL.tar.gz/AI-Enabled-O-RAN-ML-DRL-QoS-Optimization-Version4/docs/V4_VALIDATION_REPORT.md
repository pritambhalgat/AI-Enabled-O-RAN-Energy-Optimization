# Version 4 validation report — corrected software integration smoke test

## Code and test checks

- `python -m compileall -q .`: passed.
- Unit tests: **6 passed**.
- The tests cover receiver-rate calculations with the revised channel scale, shape and positive-semidefinite properties of the conditional Gaussian posterior, posterior rate-quantile output, conformal-quantile handling, the calibration block-maximum score construction, and power-budget preservation by the shield fallback/projection.

## End-to-end integration run

The revised source completed one deliberately small integration run:

- Demand model: 2 training epochs.
- Each of the MRC, ZF and MMSE PPO agents: 2 episodes × 3 steps.
- Channel calibration: 20 independent channel realizations per receiver.
- Evaluation: 2 test seeds × 3 blocks per seed.
- The full run generated per-seed metrics, summary confidence intervals, traffic-bound coverage and method-specific channel lower-bound coverage files.

The demand model's MAE in this tiny run was **0.035915**, compared with **0.029443** for persistence. The MLP did not beat persistence. The block-maximum empirical calibration coverage on the 20 calibration units was 100% for all user/receiver pairs; at this sample size, the 95% finite-sample quantile is the sample maximum, so this is not evidence of 95% out-of-sample coverage.

The two-seed, six-block evaluation is only an integration check. The resulting receiver/method metrics and t-based intervals are too small-sample to support performance comparisons. Some shield projections failed, as expected for a local solver with non-convex constraints. A solver success flag is not a proof of global feasibility or robust QoS satisfaction.

## What changed versus the earlier Version 4 package

1. Replaced additive perturbation around \(\widehat H\) with the conditional complex-Gaussian posterior implied by the channel prior and CSI-error covariance.
2. Replaced mean-normalized path loss with a close-in 1 m path-loss model at 3.5 GHz, including log-normal shadowing. Replaced the arbitrary noise value with an approximately -94 dBm thermal-noise-plus-noise-figure assumption over 20 MHz.
3. Changed channel calibration from multiple dependent action scores per channel realization to one component-wise block-maximum score vector per independent channel realization and receiver, over four predeclared action families.
4. Added evaluation coverage diagnostics for each action method, not only raw PPO.
5. Clarified the previous-command state feature: it matches unshielded PPO training; feeding shielded/applied power back into the policy requires retraining.
6. Published the complete source package and added continuous integration for compile and unit-test checks.

## Not established

- The demand MLP has not demonstrated a reliable gain over persistence.
- The calibration design does not guarantee coverage for arbitrary projected actions, adaptive policies, distribution shift or all users simultaneously.
- The shield is not guaranteed feasible; its fallback preserves the sum-power budget only.
- PPO superiority, positive energy savings, measured hardware power reduction, live O-RAN operation, A1/E2 integration and production xApp/rApp deployment are not established.

## Required before research or publication claims

- Use separate independent training, calibration, validation and test trajectories/seeds; quantify variability across multiple training seeds.
- Evaluate at least 10–20 held-out test seeds and hundreds or thousands of channel blocks per scenario.
- Increase calibration units substantially and report per-user/receiver coverage with uncertainty. Include explicit calibration diagnostics for shield-selected actions and study whether the block-maximum action family is adequate.
- Compare persistence, equal allocation, channel heuristic, raw PPO, uncalibrated shield, calibrated shield, constrained PPO/Lagrangian methods, and suitable optimization baselines.
- Report QoS violation probability, shortfall, solver failure, solver runtime, throughput, assumed energy efficiency, fairness, power and robustness under CSI/traffic/path-loss shifts.
- Validate the link budget and circuit-power model against a clearly stated target deployment or keep all energy results explicitly simulation-based.
- Conduct a systematic literature review before claiming novelty.
